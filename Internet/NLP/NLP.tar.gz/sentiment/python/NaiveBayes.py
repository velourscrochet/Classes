# NLP Programming Assignment #3
# NaiveBayes
# 2012

#
# The area for you to implement is marked with TODO!
# Generally, you should not need to touch things *not* marked TODO
#
# Remember that when you submit your code, it is not run from the command line 
# and your main() will *not* be run. To be safest, restrict your changes to
# addExample() and classify() and anything you further invoke from there.
#


import sys
import getopt
import os
import math
import collections

class NaiveBayes:
  class TrainSplit:#WHAT THE FUCK IS THIS?
    """Represents a set of training/testing data. self.train is a list of Examples, as is self.test. 
    """
    def __init__(self):
      self.train = []
      self.test = []

  class Example:###WTF MATE?
    """Represents a document with a label. klass is 'pos' or 'neg' by convention.
       words is a list of strings.
    """
    def __init__(self):
      self.klass = ''
      self.words = []


  def __init__(self):
    """NaiveBayes initialization"""
    self.FILTER_STOP_WORDS = False
    self.stopList = set(self.readFile('../data/english.stop'))
    self.numFolds = 10
    self.WordCountAll = 0
    self.WordCountPos = 0
    self.WordCountNeg = 0
    self.VocabTallyAll = collections.defaultdict(lambda: 0)
    self.VocabTallyPos = collections.defaultdict(lambda: 0)
    self.VocabTallyNeg = collections.defaultdict(lambda: 0)
    self.VocabTallyTest = collections.defaultdict(lambda: 0)
    self.NumDocsPos = 0
    self.NumDocsNeg = 0
    self.NumDocsAll = 0
    self.PriorPos = 0
    self.PriorNeg = 0
    self.DiffWordsPos = 0
    self.DiffWordsNeg = 0
    self.DiffWordsAll = 0
    self.CondPriorPos = collections.defaultdict(lambda: 0)
    self.CondPriorNeg = collections.defaultdict(lambda: 0)

  #############################################################################
  # TODO TODO TODO TODO TODO 
  
  def classify(self, words):
    """ TODO
      'words' is a list of words to classify. Return 'pos' or 'neg' classification.
    """
    scorePos = math.log10(float(self.PriorPos))
    scoreNeg = math.log10(float(self.PriorNeg))
    for i in range(0,len(words)):
	CurrentWord = words[i]
	#positive test
	if self.CondPriorPos[CurrentWord] > 0:
	    scorePos += math.log10(float(self.CondPriorPos[CurrentWord]))
#	    print self.CondPriorNeg[CurrentWord]
#	if scorePos < 0:
#	    X = raw_input("OH GOD NO!!!!")
	#negative test
	if self.CondPriorNeg[CurrentWord] > 0:
            scoreNeg += math.log10(float(self.CondPriorNeg[CurrentWord]))
    print "score pos: ",scorePos,", score neg: ",scoreNeg
    if scorePos > scoreNeg:
	print 'pos'
	return 'pos'
    else:
	print 'neg'
	return 'neg'




  def addExample(self, klass, words):
    """
     * TODO
     * Train your model on an example document with label klass ('pos' or 'neg') and
     * words, a list of strings.
     * You should store whatever data structures you use for your classifier 
     * in the NaiveBayes class.
     * Returns nothing
    """

    if klass == "pos":
	self.NumDocsPos += 1
	for i in range(0,len(words)):
	    CurrentWord = words[i]
            self.VocabTallyPos[CurrentWord] = self.VocabTallyPos[CurrentWord] + 1		
	    self.VocabTallyAll[CurrentWord] = self.VocabTallyAll[CurrentWord] + 1		
	    self.WordCountPos += 1
	    self.WordCountAll += 1

    elif klass == "neg":
	self.NumDocsNeg += 1
	for i in range(0,len(words)):
		CurrentWord = words[i]
	        self.VocabTallyNeg[CurrentWord] = self.VocabTallyNeg[CurrentWord] + 1	
		self.VocabTallyAll[CurrentWord] = self.VocabTallyAll[CurrentWord] + 1		
		self.WordCountNeg += 1
		self.WordCountAll += 1

#    print words

    pass
      
  def processExample(self):
    """
	* solve for PriorPos, PriorNegpr
	* solve for condprob's
	*
    """
    self.DiffWordsAll = len(self.VocabTallyAll) #number diff words
    self.DiffWordsPos = len(self.VocabTallyPos) #number diff words
    self.DiffWordsNeg = len(self.VocabTallyNeg) #number diff words

    self.NumDocsAll = self.NumDocsNeg + self.NumDocsPos

    self.PriorPos = (float(self.NumDocsPos) / self.NumDocsAll)

    self.PriorNeg = (float(self.NumDocsNeg) / self.NumDocsAll)

    word = 0
    for i in range(0,len(self.VocabTallyAll.keys())):
	CurrentWord = self.VocabTallyAll.keys()[i]
#	print CurrentWord, "tally = ", self.VocabTallyPos[CurrentWord]
#	print self.VocabTallyPos[CurrentWord]
	numeratorP = (1 + float(self.VocabTallyPos[CurrentWord]))
#	print "nump",numeratorP
	denominator = (self.WordCountAll + self.DiffWordsAll)
	numeratorN = (1 + float(self.VocabTallyNeg[CurrentWord]))
#	print "numn",numeratorN


#Motherfucking Laplace Smoothed!

	self.CondPriorPos[CurrentWord] = float(numeratorP) / denominator
	self.CondPriorNeg[CurrentWord] = float(numeratorN) / denominator
#    print self.CondPriorPos[CurrentWord], self.CondPriorNeg[CurrentWord]
  # TODO TODO TODO TODO TODO 
  #############################################################################
  
  
  def readFile(self, fileName):
    """
     * Code for reading a file.  you probably don't want to modify anything here, 
     * unless you don't like the way we segment files.
    """
    contents = []
    f = open(fileName)
    for line in f:
      contents.append(line)
    f.close()
    result = self.segmentWords('\n'.join(contents)) 
    return result

  
  def segmentWords(self, s):
    """
     * Splits lines on whitespace for file reading
    """
    return s.split()

  
  def trainSplit(self, trainDir): #WHAT THE FUCK DO I DO?
    """Takes in a trainDir, returns one TrainSplit with train set."""
    split = self.TrainSplit()
    posTrainFileNames = os.listdir('%s/pos/' % trainDir)
    negTrainFileNames = os.listdir('%s/neg/' % trainDir)
    for fileName in posTrainFileNames:
      example = self.Example()
      example.words = self.readFile('%s/pos/%s' % (trainDir, fileName))
      example.klass = 'pos'
      split.train.append(example)
    for fileName in negTrainFileNames:
      example = self.Example()
      example.words = self.readFile('%s/neg/%s' % (trainDir, fileName))
      example.klass = 'neg'
      split.train.append(example)
    return split

  def train(self, split): #WHAT THE FUCK DO I DO?
    for example in split.train:
      words = example.words
      if self.FILTER_STOP_WORDS:
        words =  self.filterStopWords(words)
      self.addExample(example.klass, words)
      self.processExample()

  def crossValidationSplits(self, trainDir): #WHAT THE FUCK DO I DO?
    """Returns a lsit of TrainSplits corresponding to the cross validation splits."""
    splits = [] 
    posTrainFileNames = os.listdir('%s/pos/' % trainDir)
    negTrainFileNames = os.listdir('%s/neg/' % trainDir)
    #for fileName in trainFileNames:
    for fold in range(0, self.numFolds):
      split = self.TrainSplit()
      for fileName in posTrainFileNames:
        example = self.Example()
        example.words = self.readFile('%s/pos/%s' % (trainDir, fileName))
        example.klass = 'pos'
        if fileName[2] == str(fold):
          split.test.append(example)
        else:
          split.train.append(example)
      for fileName in negTrainFileNames:
        example = self.Example()
        example.words = self.readFile('%s/neg/%s' % (trainDir, fileName))
        example.klass = 'neg'
        if fileName[2] == str(fold):
          split.test.append(example)
        else:
          split.train.append(example)
      splits.append(split)
    return splits


  def test(self, split): #WHAT THE FUCK DO I DO?
    """Returns a list of labels for split.test."""
    labels = []
    for example in split.test:
      words = example.words
      if self.FILTER_STOP_WORDS:
        words =  self.filterStopWords(words)
      guess = self.classify(words)
      labels.append(guess)
    return labels
  
  def buildSplits(self, args):
    """Builds the splits for training/testing"""
    trainData = [] 
    testData = []
    splits = []
    trainDir = args[0]
    if len(args) == 1: 
      print '[INFO]\tPerforming %d-fold cross-validation on data set:\t%s' % (self.numFolds, trainDir)

      posTrainFileNames = os.listdir('%s/pos/' % trainDir)
      negTrainFileNames = os.listdir('%s/neg/' % trainDir)
      for fold in range(0, self.numFolds):
        split = self.TrainSplit()
        for fileName in posTrainFileNames:
          example = self.Example()
          example.words = self.readFile('%s/pos/%s' % (trainDir, fileName))
          example.klass = 'pos'
          if fileName[2] == str(fold):
            split.test.append(example)
          else:
            split.train.append(example)
        for fileName in negTrainFileNames:
          example = self.Example()
          example.words = self.readFile('%s/neg/%s' % (trainDir, fileName))
          example.klass = 'neg'
          if fileName[2] == str(fold):
            split.test.append(example)
          else:
            split.train.append(example)
        splits.append(split)
    elif len(args) == 2:
      split = self.TrainSplit()
      testDir = args[1]
      print '[INFO]\tTraining on data set:\t%s testing on data set:\t%s' % (trainDir, testDir)
      posTrainFileNames = os.listdir('%s/pos/' % trainDir)
      negTrainFileNames = os.listdir('%s/neg/' % trainDir)
      for fileName in posTrainFileNames:
        example = self.Example()
        example.words = self.readFile('%s/pos/%s' % (trainDir, fileName))
        example.klass = 'pos'
        split.train.append(example)
      for fileName in negTrainFileNames:
        example = self.Example()
        example.words = self.readFile('%s/neg/%s' % (trainDir, fileName))
        example.klass = 'neg'
        split.train.append(example)

      posTestFileNames = os.listdir('%s/pos/' % testDir)
      negTestFileNames = os.listdir('%s/neg/' % testDir)
      for fileName in posTestFileNames:
        example = self.Example()
        example.words = self.readFile('%s/pos/%s' % (testDir, fileName)) 
        example.klass = 'pos'
        split.test.append(example)
      for fileName in negTestFileNames:
        example = self.Example()
        example.words = self.readFile('%s/neg/%s' % (testDir, fileName)) 
        example.klass = 'neg'
        split.test.append(example)
      splits.append(split)
    return splits
  
  def filterStopWords(self, words):
    """Filters stop words."""
    filtered = []
    for word in words:
      if not word in self.stopList and word.strip() != '':
        filtered.append(word)
    return filtered



def main():
  nb = NaiveBayes()
  (options, args) = getopt.getopt(sys.argv[1:], 'f')
  if ('-f','') in options:
    nb.FILTER_STOP_WORDS = True
  
  splits = nb.buildSplits(args)
  avgAccuracy = 0.0
  fold = 0
  for split in splits:
    classifier = NaiveBayes()
    accuracy = 0.0
    for example in split.train:
      words = example.words
      if nb.FILTER_STOP_WORDS:
        words =  classifier.filterStopWords(words)
      classifier.addExample(example.klass, words)
    classifier.processExample()
    for example in split.test:
      words = example.words
      if nb.FILTER_STOP_WORDS:
        words =  classifier.filterStopWords(words)
      guess = classifier.classify(words)
      if example.klass == guess:
        accuracy += 1.0

    accuracy = accuracy / len(split.test)
    avgAccuracy += accuracy
    print '[INFO]\tFold %d Accuracy: %f' % (fold, accuracy) 
    fold += 1
  avgAccuracy = avgAccuracy / fold
  print '[INFO]\tAccuracy: %f' % avgAccuracy

if __name__ == "__main__":
    main()
